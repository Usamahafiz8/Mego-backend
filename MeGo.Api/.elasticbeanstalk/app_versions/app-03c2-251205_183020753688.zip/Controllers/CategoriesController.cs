// // Controllers/CategoriesController.cs
// using Microsoft.AspNetCore.Mvc;
// using Microsoft.EntityFrameworkCore;
// using MeGo.Api.Data;
// using MeGo.Api.Models;
// using System;
// using System.Threading.Tasks;
// using System.Linq;

// namespace MeGo.Api.Controllers
// {
//     [ApiController]
//     [Route("v1/[controller]")]
//     public class CategoriesController : ControllerBase
//     {
//         private readonly AppDbContext _context;

//         public CategoriesController(AppDbContext context)
//         {
//             _context = context;
//         }

//         [HttpGet]
//         public async Task<IActionResult> GetCategories()
//         {
//             var categories = await _context.Categories.ToListAsync(); // ✅ Ads include hata diya
//             return Ok(categories);
//         }
//     }
// }
