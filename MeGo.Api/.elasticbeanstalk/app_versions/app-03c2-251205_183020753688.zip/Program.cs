using MeGo.Api.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using MeGo.Api.Services;
using MeGo.Api.Hubs;
using MeGo.Api.Filters;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);

// --------------------------------------------------
// 🧩 Core Services
// --------------------------------------------------
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    });

builder.Services.AddEndpointsApiExplorer();

// --------------------------------------------------
// 🧠 Application Services
// --------------------------------------------------
builder.Services.AddScoped<RewardService>();
builder.Services.AddSingleton<NotificationService>();
builder.Services.AddSingleton<EmailService>();
builder.Services.AddScoped<TwilioVerifyService>();
builder.Services.AddScoped<AdQualityScoreService>();
builder.Services.AddScoped<SpamDetectionService>();
builder.Services.AddHostedService<AdRelistReminderService>();

// --------------------------------------------------
// 🗃️ Database Context
// --------------------------------------------------
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

// --------------------------------------------------
// 🔐 JWT Authentication
// --------------------------------------------------
var jwtSettings = builder.Configuration.GetSection("Jwt");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtSettings["Issuer"],
            ValidAudience = jwtSettings["Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(jwtSettings["Key"] ?? string.Empty))
        };

        // ✅ Allow JWT token for SignalR via query string
        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = context =>
            {
                var accessToken = context.Request.Query["access_token"];
                var path = context.HttpContext.Request.Path;

                // Support both admin and chat hubs
                if (!string.IsNullOrEmpty(accessToken) &&
                    (path.StartsWithSegments("/hubs/admin") || path.StartsWithSegments("/chatHub")))
                {
                    context.Token = accessToken;
                }

                return Task.CompletedTask;
            }
        };
    });

// --------------------------------------------------
// 🌐 CORS (Frontend Communication)
// --------------------------------------------------
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", policy =>
        policy.WithOrigins(
                "http://localhost:3000",
                "http://localhost:3001",
                "https://mego-admin.vercel.app",
                "http://192.168.0.105:3000",
                "http://localhost:3002", // Website default port
                "http://127.0.0.1:3000",
                "http://127.0.0.1:3001",
                "http://127.0.0.1:3002") // 🔧 add deployed frontend here
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials());
});

// --------------------------------------------------
// 📡 SignalR (Admin & Chat Hubs)
// --------------------------------------------------
builder.Services.AddSignalR(options =>
{
    options.EnableDetailedErrors = true;
    options.MaximumReceiveMessageSize = 1024 * 1024; // 1MB
});

// --------------------------------------------------
// 🧾 Swagger (API Docs)
// --------------------------------------------------
builder.Services.AddSwaggerGen(c =>
{
    c.SupportNonNullableReferenceTypes();
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "MeGo API",
        Description = "MeGo Admin & App Backend"
    });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: Bearer {token}",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            new string[] { }
        }
    });

    // Handle file uploads in Swagger
    c.OperationFilter<FileUploadOperationFilter>();
});

// --------------------------------------------------
// 🚀 Build Application
// --------------------------------------------------
var app = builder.Build();

// --------------------------------------------------
// 🧰 Middleware Pipeline
// --------------------------------------------------
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "MeGo API v1");
});

app.UseCors("CorsPolicy");
app.UseAuthentication();
app.UseAuthorization();

// 📁 Serve static uploads (images, etc.)
app.UseStaticFiles();
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(
        Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads")),
    RequestPath = "/uploads"
});

// --------------------------------------------------
// 📍 Endpoints
// --------------------------------------------------
app.MapControllers();
app.MapHub<AdminHub>("/hubs/admin");
app.MapHub<ChatHub>("/chatHub");
app.MapHub<UserHub>("/userHub");
app.MapGet("/", () => "🚀 MeGo Admin Backend is running perfectly!");

// --------------------------------------------------
app.Run();
